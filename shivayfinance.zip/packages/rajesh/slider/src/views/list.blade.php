@extends('rajesh.slider.src.layout.master')
@section('content')
        <h3>Edit : </h3>
        
        <h3>Add New Task : </h3>
        
        <div class="form-inline">
            <div class="form-group">
            </div>
            <div class="form-group">
            </div>
        </div>
    <hr>
    <h4>Tasks To Do : </h4>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
                <tr>
                    <td></td>
                    <td>
                    </td>
                </tr>
        </tbody>
    </table>
@endsection