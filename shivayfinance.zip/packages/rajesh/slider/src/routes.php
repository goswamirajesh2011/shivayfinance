<?php
Route::resource('/slider', 'Rajesh\Slider\SliderController');